﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineEmulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Machine machine = new Machine();
            machine.Run();
            Console.ReadLine();
        }
    }
}
