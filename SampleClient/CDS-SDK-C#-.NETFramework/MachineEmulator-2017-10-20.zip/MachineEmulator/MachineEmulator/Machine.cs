﻿using Microsoft.Azure.Devices.Client;
using Microsoft.Azure.Devices.Shared;
using Microsoft.CDS.Devices.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineEmulator
{
    class Machine
    {
        static int _CompanyId, _MessageCatalogId, _MessageSendInterval;
        static string _IoTDeviceId, _IoTDevicePW, _EquipmentId, _RunProgram;
        static SfDeviceClient _sfDeviceClient;

        public Machine()
        {
            _CompanyId = int.Parse(ConfigurationManager.AppSettings["Company.Id"]);
            _IoTDeviceId = ConfigurationManager.AppSettings["IoTDevice.Id"];
            _IoTDevicePW = ConfigurationManager.AppSettings["IoTDevice.Password"];
            _EquipmentId = ConfigurationManager.AppSettings["Equipment.Id"];
            _RunProgram = ConfigurationManager.AppSettings["RunProgram"];
            _MessageSendInterval = int.Parse(ConfigurationManager.AppSettings["MessageSendInterval"].ToString());

            /* Setup Device Credential */
            HwProductKey hwProductKey = LoadHwProductKey(true);

            /* Create the instance of SfDeviceClient */
            _sfDeviceClient = SfDeviceClient.CreateSfDeviceClient(hwProductKey, ConfigurationManager.AppSettings["CertificatePath"]);

            /* initialzation */
            _sfDeviceClient.Initial().Wait();
        }

        public void Run()
        {
            try
            {
                /* Getting device twin */
                //GetTwinPropertiesAsync();

                /* Setup the Customer properties callback */
                //_sfDeviceClient.SetCustomerPropertiesUpdateCallbackAsync(OnDesiredPropertiesChanged).Wait();

                /* Send Telemetry */
                SendTelemetry();

                /* Receive Cloud To Devce Message */
                //ReceiveCloudToDeviceMessageAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex.Message);
                if (ex.InnerException != null)
                {
                    Console.WriteLine("InnerException: {0}", ex.InnerException.Message);
                    Console.WriteLine("InnerException StackTrace: {0}", ex.InnerException.StackTrace);
                }
            }
            Console.ReadLine();
        }

        private static HwProductKey LoadHwProductKey(bool isConfigLoaded)
        {
            HwProductKey hwProductKey = null;
            try
            {
                if (isConfigLoaded)
                {
                    hwProductKey = HwProductKey.CreateHwProductKey(_IoTDeviceId, _IoTDevicePW);
                }
                else
                {
                    // put something here in the real hareward product, such as getting the serial number...
                    // To do
                }

                Console.WriteLine("hwProductKey.email={0}, hwProductKey.password={1}", hwProductKey.email, hwProductKey.password);
            }
            catch (Exception ex)
            {
                Console.WriteLine("loadHwProductKey Exception: {0}", ex.Message);
                return null;
            }

            return hwProductKey;
        }

        private static async void GetTwinPropertiesAsync()
        {
            /* Get Twin */
            Twin twin = await _sfDeviceClient.GetTwinAsync();
            if (twin != null)
            {
                 /* Get Desired Customer Properties */
                JObject desiredProperties = await _sfDeviceClient.GetDesiredCustomerPropertiesAsync();

                await processDesiredCustomerProperty(desiredProperties);
            }
        }

        private static async Task OnDesiredPropertiesChanged(JObject desiredProperties)
        {
            Console.WriteLine("Desired Property Change:");

            if (desiredProperties == null)
            {
                Console.WriteLine("desiredProperties: null");
                return;
            }

            await processDesiredCustomerProperty(desiredProperties);
        }

        private static async Task processDesiredCustomerProperty(JObject desiredProperties)
        {
            if (desiredProperties == null)
                return;

            JObject reportedProperties = new JObject();
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            foreach (JProperty jp in desiredProperties.Properties())
            {
                switch (jp.Name)
                {
                    case "MessageSendInterval":
                        _MessageSendInterval = int.Parse(jp.Value.ToString());
                        config.AppSettings.Settings[jp.Name].Value = jp.Value.ToString();
                        config.Save(ConfigurationSaveMode.Modified);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Change Message Send Interval to {0} seconds\n", _MessageSendInterval);
                        Console.ForegroundColor = ConsoleColor.White;

                        // Update the reported customer property
                        reportedProperties.Add(jp.Name, jp.Value);
                        break;
                    case "RunProgram":
                        _RunProgram = jp.Value.ToString();
                        config.AppSettings.Settings[jp.Name].Value = jp.Value.ToString();
                        config.Save(ConfigurationSaveMode.Modified);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Change Run Program to {0}\n", _RunProgram);
                        Console.ForegroundColor = ConsoleColor.White;

                        // Update the reported customer property
                        reportedProperties.Add(jp.Name, jp.Value);
                        break;
                }
            }
            await _sfDeviceClient.UpdateReportedCustomerPropertiesAsync(reportedProperties);
        }

        private async void SendTelemetry()
        {
            while (true)
            {
                try
                {
                    DateTime DTNow = DateTime.UtcNow;

                    string deviceMessage = getSampleDeviceMessage();
                    await _sfDeviceClient.SendEventAsyncWithRetry(_MessageCatalogId, deviceMessage);
                    Console.WriteLine("{0} > Sending message.", DTNow);

                    Task.Delay(_MessageSendInterval * 1000).Wait();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("SendAsync Exception: {0}", ex.ToString());
                }
            }
        }

        private string getSampleDeviceMessage()
        {
            JObject deviceMessage = new JObject();
            deviceMessage.Add("companyId", _CompanyId);
            deviceMessage.Add("msgTimestamp", DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"));
            deviceMessage.Add("equipmentId", _EquipmentId);
            deviceMessage.Add("equipmentRunStatus", 1);
            
            _MessageCatalogId = 0;
            deviceMessage.Add("fieldName1", "Hello CDS");
            deviceMessage.Add("fieldName2", 100);
            deviceMessage.Add("fieldName3", 200);

            /* Device Management */
            //switch (_RunProgram.ToUpper())
            //{
            //    case "A":
            //        _MessageCatalogId = 0;
            //        deviceMessage.Add("fieldName1", _RunProgram);
            //        deviceMessage.Add("fieldName2", 100);
            //        deviceMessage.Add("fieldName3", 200);
            //        break;
            //    case "B":
            //        _MessageCatalogId = 0;
            //        deviceMessage.Add("fieldName1", _RunProgram);
            //        deviceMessage.Add("fieldName2", 100);
            //        deviceMessage.Add("fieldName3", 200);
            //        break;
            //    default:                    
            //        break;
            //}

            return deviceMessage.ToString();
        }

        private async void ReceiveCloudToDeviceMessageAsync()
        {
            while (true)
            {
                try
                {
                    Message receivedMessage = await _sfDeviceClient.ReceiveAsync();
                    if (receivedMessage == null)
                        continue;// It returns null after a specifiable timeout period (in this case, the default of one minute is used)

                    string msg = Encoding.ASCII.GetString(receivedMessage.GetBytes());
                    await _sfDeviceClient.CompleteAsync(receivedMessage);

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Received message: {0}\n", msg);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                catch (Exception)
                {
                    ;
                }
            }
        }
    }
}
