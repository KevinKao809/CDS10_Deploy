﻿using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ClientApp
{
    class Gateway
    {
        int _CompanyId = 53;                    // Change to your company ID
        int _MessageSendInterval = 10;          
        DeviceClient _CDSClient;
        public Gateway(DeviceClient cdsClient)
        {
            _CDSClient = cdsClient;
        }

        public void Run()
        {
            try
            {   
                /* Send Telemetry */
                SendTelemetry();

                /* Receive Cloud To Devce Message */
                ReceiveCloudToDeviceMessageAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex.Message);
                if (ex.InnerException != null)
                {
                    Console.WriteLine("InnerException: {0}", ex.InnerException.Message);
                    Console.WriteLine("InnerException StackTrace: {0}", ex.InnerException.StackTrace);
                }
            }
        }

        private async void SendTelemetry()
        {
            while (true)
            {
                try
                {
                    DateTime DTNow = DateTime.UtcNow;

                    List<Message> messages = getDeviceMessages();
                    await _CDSClient.SendEventBatchAsync(messages);                   
                    Console.WriteLine("{0} > Sending message.", DTNow);

                    Task.Delay(_MessageSendInterval * 1000).Wait();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("SendAsync Exception: {0}", ex.ToString());
                }
            }
        }

        private List<Message> getDeviceMessages()
        {
            string device01Msg = getEquipmentTelemetry("AAL100124b0009b53b4b");
            var message01 = new Message(Encoding.ASCII.GetBytes(device01Msg));
            message01.Properties.Add("MessageCatalogId", "258");
            message01.Properties.Add("Type", "Message");

            string device02Msg = getEquipmentTelemetry("AAL100124b0009b540a4");
            var message02 = new Message(Encoding.ASCII.GetBytes(device02Msg));
            message02.Properties.Add("MessageCatalogId", "258");
            message02.Properties.Add("Type", "Message");

            List<Message> messageList = new List<Message>();
            messageList.Add(message01);
            messageList.Add(message02);
            return messageList;        
        }

        private string getEquipmentTelemetry(string equipmentId)
        {
            var telemetry = new
            {
                companyId = _CompanyId,
                msgTimestamp = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                equipmentId = equipmentId,
                equipmentRunStatus = 1,
                a = 10,
                dim = 20,
                freq = 30,
                kwh = 40,
                lux = 50,
                pf = 60,
                v = 70,
                w = 70
            };
            return JsonConvert.SerializeObject(telemetry);
        }        

        private async void ReceiveCloudToDeviceMessageAsync()
        {
            while (true)
            {
                try
                {
                    Message receivedMessage = await _CDSClient.ReceiveAsync();
                    if (receivedMessage == null)
                        continue;// It returns null after a specifiable timeout period (in this case, the default of one minute is used)

                    string msg = Encoding.ASCII.GetString(receivedMessage.GetBytes());
                    await _CDSClient.CompleteAsync(receivedMessage);

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Received message: {0}\n", msg);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                catch (Exception)
                {
                    ;
                }
            }
        }
    }
}
