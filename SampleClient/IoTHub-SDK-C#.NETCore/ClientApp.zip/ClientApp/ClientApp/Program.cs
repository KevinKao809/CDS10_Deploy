﻿using Microsoft.Azure.Devices.Client;
using System;

namespace ClientApp
{
    class Program
    {
        static string APIURL = "http://msfapiservice.trafficmanager.net/";      // Change to Your API URL
        static string GatewayID = "xxxxxxx";                         // Change to Your IoTDeviceID
        static string GatewayPW = "xxxxxxx";                                     // Change to Your IoTDevicePassword
        static void Main(string[] args)
        {
            CDSHelper cdsHelper = new CDSHelper(APIURL, GatewayID, GatewayPW);
            cdsHelper.Connect().Wait();
            if (CDSHelper._CDSClient != null)
            {
                Gateway gateway = new Gateway(CDSHelper._CDSClient);
                gateway.Run();
            }
            Console.WriteLine("Please any key to exit");
            Console.ReadKey();
        }
    }
}
